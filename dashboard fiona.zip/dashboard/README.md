# Outpatient Appointment Prediction Dashboard

A comprehensive Streamlit application for predicting patient appointment outcomes with advanced analytics and DNS (Did Not Show) risk scoring.

## Features

### Admin Features
- **Authentication System**: Secure login for admin and user accounts
- **Monthly Calendar View**: Visual calendar with appointment counts per day
- **DNS Risk Score Calculation**: Advanced risk scoring algorithm for predicting no-show probability
- **DNS Score Saving**: Persistent storage of risk scores and patient data
- **Model Retraining**: Capability to retrain the ML model with new data
- **Enhanced Analytics Dashboard**: Comprehensive charts and statistics
- **Bulk Prediction**: Process multiple patients with DNS scores
- **Data Export**: Export data in CSV, Excel, or JSON formats

### User Features
- **Simple Form Completion**: Easy-to-use appointment request form
- **Basic Patient Information**: Personal details and appointment preferences

## Installation

1. Install required dependencies:
```bash
pip install -r requirements.txt
```

2. Ensure you have the following files in your directory:
   - `app.py` (main application)
   - `random_forest_model.pkl` (trained ML model)
   - `ddata_fsh_outpatients.csv` (patient data)

## Usage

1. Run the application:
```bash
streamlit run app.py
```

2. Login with credentials:
   - **Admin**: username: `admin`, password: `admin123`
   - **User**: username: `user`, password: `user123`

## Admin Dashboard Features

### Prediction & DNS Score
- Enter patient details to get appointment outcome prediction
- Calculate DNS risk score (0-100) with detailed risk factor breakdown
- Save DNS scores for future reference

### Monthly Calendar
- View appointment counts by day for any month
- Analyze DNS rates and appointment patterns
- Export daily summaries

### Analytics Dashboard
- Overview metrics (total appointments, DNS rates, attendance rates)
- Clinic-specific analysis
- Demographic breakdowns
- Time trend analysis

### Bulk Prediction
- Upload CSV files for batch processing
- Generate predictions and DNS scores for multiple patients
- Export results with all calculated metrics

### Model Retraining
- Retrain the machine learning model with latest data
- View model performance metrics
- Update model for improved predictions

### Data Export
- Filter data by date range, clinic, or outcome
- Export in multiple formats (CSV, Excel, JSON)
- Customizable data selection

## User Dashboard Features

### Simple Appointment Form
- Personal information collection
- Appointment preferences
- Medical history and requirements
- Form validation and submission

## DNS Risk Score Algorithm

The DNS risk score is calculated based on multiple factors:
- Age-based risk (younger patients higher risk)
- Gender, indigenous status, marital status
- Language and interpreter requirements
- Geographic and clinic-specific factors
- Day of week patterns
- Historical appointment behavior
- Multiple appointments on same day

## File Structure

```
dashboard/
├── app.py                          # Main application
├── requirements.txt                # Python dependencies
├── random_forest_model.pkl         # Trained ML model
├── ddata_fsh_outpatients.csv       # Patient data
├── dns_scores.json                 # DNS scores storage (created automatically)
└── README.md                       # This file
```

## Security Notes

- Default credentials are hardcoded for demonstration
- In production, implement proper user authentication and database storage
- Consider encrypting sensitive patient data
- Implement proper session management and access controls

## Support

For issues or questions, please check the application logs or contact the development team.
