import streamlit as st
import pandas as pd
import joblib
import numpy as np

# ==============================
# Load Trained Model
# ==============================
model = joblib.load("random_forest_model.pkl")

st.set_page_config(page_title="Outpatient No-Show Prediction", layout="wide")
st.title("🏥 Outpatient Appointment Prediction Dashboard")

st.write("This dashboard predicts whether a patient will **Attend, Miss (DNA), or Reschedule** their appointment.")

# ==============================
# Feature Mappings (from your table)
# ==============================
mappings = {
    "appointment_outcome": {0: "Attended", 1: "DNA", 2: "Rescheduled"},
    "gender": {0: "Female", 1: "Male"},
    "indigenous_status": {0: "Aboriginal", 1: "Both", 2: "Neither", 3: "Torres Strait Islander"},
    "marital_status": {0: "Divorced", 1: "Married", 2: "Single", 3: "Widowed"},
    "country_of_birth": {0: "Australia", 1: "China", 2: "India", 3: "New Zealand", 4: "South Africa", 5: "UK", 6: "Vietnam"},
    "preferred_language": {0: "English", 1: "Hindu", 2: "Mandarin"},
    "interpreter_required": {0: "No", 1: "Yes"},
    "suburb": {0: "Bateman", 1: "Bull Creek", 2: "Fremantle", 3: "Kardinya", 4: "Leeming", 5: "Murdoch", 6: "North Lake", 7: "Palmyra", 8: "Willetton", 9: "Winthrop"},
    "clinic": {0: "Cardiology", 1: "Diabetes", 2: "ENT", 3: "Endocrinology", 4: "Gastroenterology", 5: "Neurology", 6: "Oncology", 7: "Ophthalmology", 8: "Orthopedics", 9: "Urology"},
    "day_of_week": {0: "Monday", 1: "Tuesday", 2: "Wednesday", 3: "Thursday", 4: "Friday", 5: "Saturday", 6: "Sunday"}
}

# Reverse mappings for dropdown selection
reverse_mappings = {col: {v: k for k, v in mapping.items()} for col, mapping in mappings.items()}

# ==============================
# Sidebar Input
# ==============================
st.sidebar.header("🔍 Enter Patient Details")

age = st.sidebar.slider("Age", min_value=0, max_value=100, value=40)
gender = st.sidebar.selectbox("Gender", list(reverse_mappings["gender"].keys()))
indigenous_status = st.sidebar.selectbox("Indigenous Status", list(reverse_mappings["indigenous_status"].keys()))
marital_status = st.sidebar.selectbox("Marital Status", list(reverse_mappings["marital_status"].keys()))
country_of_birth = st.sidebar.selectbox("Country of Birth", list(reverse_mappings["country_of_birth"].keys()))
preferred_language = st.sidebar.selectbox("Preferred Language", list(reverse_mappings["preferred_language"].keys()))
interpreter_required = st.sidebar.selectbox("Interpreter Required", list(reverse_mappings["interpreter_required"].keys()))
suburb = st.sidebar.selectbox("Suburb", list(reverse_mappings["suburb"].keys()))
clinic = st.sidebar.selectbox("Clinic", list(reverse_mappings["clinic"].keys()))
day_of_week = st.sidebar.selectbox("Day of Week", list(reverse_mappings["day_of_week"].keys()))

is_last_appt_dns = st.sidebar.selectbox("Last Appointment DNA?", [0, 1])
has_multiple_appts_same_day = st.sidebar.selectbox("Multiple Appointments Same Day?", [0, 1])
appointments_attended = st.sidebar.number_input("Appointments Attended", 0, 100, 5)
appointments_missed = st.sidebar.number_input("Appointments Missed", 0, 50, 1)
appointments_rescheduled = st.sidebar.number_input("Appointments Rescheduled", 0, 50, 0)

# ==============================
# Prepare Input Data
# ==============================
input_data = pd.DataFrame([[
    age,
    reverse_mappings["gender"][gender],
    reverse_mappings["indigenous_status"][indigenous_status],
    reverse_mappings["marital_status"][marital_status],
    reverse_mappings["country_of_birth"][country_of_birth],
    reverse_mappings["preferred_language"][preferred_language],
    reverse_mappings["interpreter_required"][interpreter_required],
    reverse_mappings["suburb"][suburb],
    reverse_mappings["clinic"][clinic],
    is_last_appt_dns,
    has_multiple_appts_same_day,
    appointments_attended,
    appointments_missed,
    appointments_rescheduled,
    reverse_mappings["day_of_week"][day_of_week]
]], columns=[
    "age", "gender", "indigenous_status", "marital_status", "country_of_birth",
    "preferred_language", "interpreter_required", "suburb", "clinic",
    "is_last_appt_dns", "has_multiple_appts_same_day", "appointments_attended",
    "appointments_missed", "appointments_rescheduled", "day_of_week"
])

# ==============================
# Prediction
# ==============================
if st.sidebar.button("Predict Appointment Outcome"):
    prediction = model.predict(input_data)[0]
    proba = model.predict_proba(input_data)[0]

    outcome = mappings["appointment_outcome"][prediction]
    st.subheader("🎯 Prediction Result")
    st.write(f"**Predicted Outcome:** {outcome}")
    
    st.write("### 🔢 Prediction Probabilities")
    prob_df = pd.DataFrame({
        "Outcome": [mappings["appointment_outcome"][i] for i in range(len(proba))],
        "Probability": proba
    })
    st.bar_chart(prob_df.set_index("Outcome"))

# ==============================
# CSV Upload for Bulk Predictions
# ==============================
st.subheader("📂 Upload CSV for Bulk Predictions")
file_upload = st.file_uploader("Upload your dataset (encoded values)", type=["csv"])

if file_upload:
    df_upload = pd.read_csv(file_upload)
    preds = model.predict(df_upload)
    df_upload["Predicted_Outcome"] = [mappings["appointment_outcome"][p] for p in preds]
    st.write("### Prediction Results", df_upload.head())
    st.download_button("⬇ Download Results", df_upload.to_csv(index=False), file_name="predictions.csv", mime="text/csv")
