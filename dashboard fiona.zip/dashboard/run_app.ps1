Write-Host "Starting Outpatient Appointment Prediction Dashboard..." -ForegroundColor Green
Write-Host ""
Write-Host "Admin Login: username=admin, password=admin123" -ForegroundColor Yellow
Write-Host "User Login: username=user, password=user123" -ForegroundColor Yellow
Write-Host ""
streamlit run app.py
