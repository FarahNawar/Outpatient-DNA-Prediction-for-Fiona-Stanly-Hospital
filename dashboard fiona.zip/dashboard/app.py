import streamlit as st
import pandas as pd
import joblib
import numpy as np
import hashlib
import datetime
from datetime import datetime, timedelta
import plotly.express as px
import json
import base64
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from typing import Optional

# ==============================
# Configuration
# ==============================
st.set_page_config(page_title="Outpatient No-Show Prediction", layout="wide")

# ==============================
# Global Background Image
# ==============================
def _load_default_bg_bytes():
    try:
        possible_names_lower = {"login_bg.jpg", "login_bg.jpeg", "login_bg.png", "login-bg.jpg", "login-bg.png", "loginbg.jpg"}
        for fname in os.listdir("."):
            if fname.lower() in possible_names_lower or fname in ["Login_bg.jpg", "Login_bg.jpeg", "Login_bg.png"]:
                with open(fname, "rb") as f:
                    return f.read()
    except Exception:
        return None
    return None

def _apply_background(image_bytes: Optional[bytes] = None):
    """Apply background image to the main dashboard"""
    if image_bytes:
        # Convert image to base64
        encoded_image = base64.b64encode(image_bytes).decode()
        
        st.markdown(
            f"""
            <style>
                [data-testid="stAppViewContainer"] {{
                    background-image: linear-gradient(rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.8)), url("data:image/jpeg;base64,{encoded_image}");
                    background-size: cover;
                    background-position: 60% center;
                    background-repeat: no-repeat;
                    background-attachment: fixed;
                }}
            .main .block-container {{
                background: rgba(0, 0, 0, 0.95);
                backdrop-filter: blur(25px);
                border-radius: 15px;
                margin-top: 2rem;
                padding: 2rem;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.7);
                border: 2px solid rgba(255, 255, 255, 0.3);
            }}
            .stTabs [data-baseweb="tab-list"] {{
                background: rgba(0, 0, 0, 0.9);
                border-radius: 10px;
                padding: 0.5rem;
                margin-bottom: 1rem;
                border: 1px solid rgba(255, 255, 255, 0.3);
            }}
            .stSidebar {{
                background: rgba(0, 0, 0, 0.95);
                backdrop-filter: blur(20px);
                border-right: 2px solid rgba(255, 255, 255, 0.2);
            }}
            /* Sidebar button styling */
            .stSidebar .stButton > button {{
                background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
                color: #ffffff !important;
                font-weight: 700 !important;
                border: 2px solid rgba(255, 255, 255, 0.3) !important;
                border-radius: 10px !important;
                padding: 10px 15px !important;
                margin: 5px 0 !important;
                width: 100% !important;
                text-shadow: 0 2px 4px rgba(0, 0, 0, 0.8) !important;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3) !important;
            }}
            .stSidebar .stButton > button:hover {{
                background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%) !important;
                transform: translateY(-2px) !important;
                box-shadow: 0 6px 12px rgba(0, 0, 0, 0.4) !important;
            }}
            /* Ensure all text is readable */
            h1, h2, h3, h4, h5, h6, p, label, .stMarkdown, .stText, .stSelectbox label, .stSlider label {{
                color: #ffffff !important;
                text-shadow: 0 3px 6px rgba(0, 0, 0, 0.9), 0 1px 2px rgba(0, 0, 0, 0.8);
                font-weight: 600 !important;
            }}
            /* Make titles extra bold and readable */
            h1 {{
                font-weight: 800 !important;
                text-shadow: 0 4px 8px rgba(0, 0, 0, 0.9), 0 2px 4px rgba(0, 0, 0, 0.8) !important;
            }}
            /* Make form elements more visible */
            .stSelectbox > div > div, .stTextInput > div > div, .stNumberInput > div > div {{
                background: #ffffff !important;
                color: #111827 !important; /* slate-900 */
                border: 2px solid rgba(0, 0, 0, 0.35) !important;
            }}
            /* Selected value text color inside selectbox */
            .stSelectbox div[data-baseweb="select"] div[role="button"] {{
                color: #111827 !important;
            }}
            /* Dropdown menu panel and option text */
            .stSelectbox div[data-baseweb="popover"] div[role="listbox"],
            .stSelectbox div[data-baseweb="popover"] div[role="option"] {{
                background: #ffffff !important;
                color: #111827 !important;
            }}
            .stSelectbox label, .stTextInput label, .stNumberInput label, .stSlider label {{
                color: #ffffff !important;
                font-weight: 600 !important;
                text-shadow: 0 2px 4px rgba(0, 0, 0, 0.8) !important;
            }}
            </style>
            """,
            unsafe_allow_html=True,
        )
    else:
        # Default gradient background if no image
        st.markdown(
            """
            <style>
            [data-testid="stAppViewContainer"] {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                background-attachment: fixed;
            }
            .main .block-container {
                background: rgba(0, 0, 0, 0.95);
                backdrop-filter: blur(25px);
                border-radius: 15px;
                margin-top: 2rem;
                padding: 2rem;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.7);
                border: 2px solid rgba(255, 255, 255, 0.3);
            }
            .stTabs [data-baseweb="tab-list"] {
                background: rgba(0, 0, 0, 0.9);
                border-radius: 10px;
                padding: 0.5rem;
                margin-bottom: 1rem;
                border: 1px solid rgba(255, 255, 255, 0.3);
            }
            .stSidebar {
                background: rgba(0, 0, 0, 0.95);
                backdrop-filter: blur(20px);
                border-right: 2px solid rgba(255, 255, 255, 0.2);
            }
            /* Sidebar button styling */
            .stSidebar .stButton > button {
                background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
                color: #ffffff !important;
                font-weight: 700 !important;
                border: 2px solid rgba(255, 255, 255, 0.3) !important;
                border-radius: 10px !important;
                padding: 10px 15px !important;
                margin: 5px 0 !important;
                width: 100% !important;
                text-shadow: 0 2px 4px rgba(0, 0, 0, 0.8) !important;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3) !important;
            }
            .stSidebar .stButton > button:hover {
                background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%) !important;
                transform: translateY(-2px) !important;
                box-shadow: 0 6px 12px rgba(0, 0, 0, 0.4) !important;
            }
            /* Ensure all text is readable */
            h1, h2, h3, h4, h5, h6, p, label, .stMarkdown, .stText, .stSelectbox label, .stSlider label {
                color: #ffffff !important;
                text-shadow: 0 3px 6px rgba(0, 0, 0, 0.9), 0 1px 2px rgba(0, 0, 0, 0.8);
                font-weight: 600 !important;
            }
            /* Make titles extra bold and readable */
            h1 {
                font-weight: 800 !important;
                text-shadow: 0 4px 8px rgba(0, 0, 0, 0.9), 0 2px 4px rgba(0, 0, 0, 0.8) !important;
            }
            /* Make form elements more visible */
            .stSelectbox > div > div, .stTextInput > div > div, .stNumberInput > div > div {
                background: #ffffff !important;
                color: #111827 !important;
                border: 2px solid rgba(0, 0, 0, 0.35) !important;
            }
            /* Selected value text color inside selectbox */
            .stSelectbox div[data-baseweb="select"] div[role="button"] {
                color: #111827 !important;
            }
            /* Dropdown menu panel and option text */
            .stSelectbox div[data-baseweb="popover"] div[role="listbox"],
            .stSelectbox div[data-baseweb="popover"] div[role="option"] {
                background: #ffffff !important;
                color: #111827 !important;
            }
            .stSelectbox label, .stTextInput label, .stNumberInput label, .stSlider label {
                color: #ffffff !important;
                font-weight: 600 !important;
                text-shadow: 0 2px 4px rgba(0, 0, 0, 0.8) !important;
            }
            </style>
            """,
            unsafe_allow_html=True,
        )

# ==============================
# Authentication System
# ==============================
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def check_credentials(username, password):
    # Simple hardcoded credentials - in production, use a proper database
    admin_credentials = {
        "admin": hash_password("admin123"),
        "user": hash_password("user123")
    }
    
    if username in admin_credentials:
        return admin_credentials[username] == hash_password(password)
    return False

def is_admin(username):
    return username == "admin"

def login_page():
    st.title("🏥 Outpatient Appointment Prediction Dashboard")
    st.subheader("Please Login")
    
    # ---- Background setup (upload once per session) ----
    def _set_login_background(image_bytes: Optional[bytes] = None):
        if image_bytes:
            # Convert image to base64
            encoded_image = base64.b64encode(image_bytes).decode()
            
            st.markdown(
                f"""
                <style>
                /* Set background image for login page with dark overlay */
                [data-testid="stAppViewContainer"] {{
                    background-image: linear-gradient(rgba(0,0,0,0.8), rgba(0,0,0,0.8)), url("data:image/jpeg;base64,{encoded_image}");
                    background-size: cover;
                    background-position: 60% center;
                    background-repeat: no-repeat;
                    background-attachment: fixed;
                }}
                /* Center and style the login form */
                [data-testid="stForm"] {{
                    backdrop-filter: blur(18px);
                    background: rgba(0,0,0,0.6);
                    border: 1px solid rgba(255,255,255,0.35);
                    box-shadow: 0 25px 50px rgba(0,0,0,0.4);
                    border-radius: 20px;
                    padding: 32px 28px;
                    max-width: 520px;
                    margin: 10vh auto 0 auto;
                }}
                h1, h2, h3, label, .stMarkdown p {{ color: #ffffff !important; text-shadow: 0 3px 6px rgba(0,0,0,0.9); }}
                .stTextInput input, .stPassword input {{
                    background: #ffffff;
                    color: #1f2937 !important;
                    border-radius: 12px;
                    border: 2px solid rgba(0,0,0,0.35);
                }}
                .stTextInput input::placeholder, .stPassword input::placeholder {{ color: #6b7280; opacity: 1; }}
                .stButton > button {{
                    background: linear-gradient(135deg,#34d399 0%, #059669 100%);
                    color: #ffffff; font-weight: 700; border: none; border-radius: 12px;
                    box-shadow: 0 10px 20px rgba(5,150,105,0.4);
                }}
                .stButton > button:hover {{ filter: brightness(1.1); transform: translateY(-2px); }}
                </style>
                """,
                unsafe_allow_html=True,
            )
        else:
            # Default gradient background for login
            st.markdown(
            """
            <style>
                /* Set home/login page background gradient with darker overlay */
            [data-testid="stAppViewContainer"] {
                    background: linear-gradient(135deg, rgba(15,23,42,0.95) 0%, rgba(30,41,59,0.95) 100%);
                    background-attachment: fixed;
            }
            /* Center and style the login form */
            [data-testid="stForm"] {
                    backdrop-filter: blur(18px);
                    background: rgba(0,0,0,0.6);
                    border: 1px solid rgba(255,255,255,0.35);
                    box-shadow: 0 25px 50px rgba(0,0,0,0.4);
                    border-radius: 20px;
                    padding: 32px 28px;
                max-width: 520px;
                margin: 10vh auto 0 auto;
            }
                h1, h2, h3, label, .stMarkdown p { color: #ffffff !important; text-shadow: 0 3px 6px rgba(0,0,0,0.9); }
            .stTextInput input, .stPassword input {
                    background: #ffffff;
                    color: #1f2937 !important;
                    border-radius: 12px;
                    border: 2px solid rgba(0,0,0,0.35);
                }
                .stTextInput input::placeholder, .stPassword input::placeholder {{ color: #6b7280; opacity: 1; }}
            .stButton > button {
                background: linear-gradient(135deg,#34d399 0%, #059669 100%);
                    color: #ffffff; font-weight: 700; border: none; border-radius: 12px;
                    box-shadow: 0 10px 20px rgba(5,150,105,0.4);
            }
                .stButton > button:hover { filter: brightness(1.1); transform: translateY(-2px); }
            </style>
            """,
            unsafe_allow_html=True,
        )

    # Apply global background on login too (uses the same loader)
    _set_login_background(_load_default_bg_bytes())
    
    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submit_button = st.form_submit_button("Login")
        
        if submit_button:
            if check_credentials(username, password):
                st.session_state.logged_in = True
                st.session_state.username = username
                st.session_state.is_admin = is_admin(username)
                st.rerun()
            else:
                st.error("Invalid credentials")

def logout():
    for key in list(st.session_state.keys()):
        del st.session_state[key]
    st.rerun()

# ==============================
# Data Storage Functions
# ==============================
def load_data():
    """Load appointment data"""
    try:
        return pd.read_csv("ddata_fsh_outpatients.csv")
    except:
        return pd.DataFrame()

def save_dns_scores(scores_data):
    """Save DNS scores to a JSON file"""
    try:
        with open("dns_scores.json", "r") as f:
            existing_data = json.load(f)
    except:
        existing_data = []
    
    existing_data.extend(scores_data)
    
    with open("dns_scores.json", "w") as f:
        json.dump(existing_data, f, indent=2, default=str)

def load_dns_scores():
    """Load DNS scores from JSON file"""
    try:
        with open("dns_scores.json", "r") as f:
            return json.load(f)
    except:
        return []

# ==============================
# DNS Risk Score Calculation
# ==============================
def calculate_dns_risk_score(patient_data):
    """Calculate DNS (Did Not Show) Risk Score based on patient characteristics"""
    risk_factors = {
        'age_risk': 0,
        'gender_risk': 0,
        'indigenous_risk': 0,
        'marital_risk': 0,
        'language_risk': 0,
        'interpreter_risk': 0,
        'suburb_risk': 0,
        'clinic_risk': 0,
        'day_risk': 0,
        'history_risk': 0,
        'multiple_appts_risk': 0
    }
    
    # Age-based risk (younger patients more likely to miss)
    if patient_data['age'] < 25:
        risk_factors['age_risk'] = 0.3
    elif patient_data['age'] > 65:
        risk_factors['age_risk'] = 0.1
    else:
        risk_factors['age_risk'] = 0.2
    
    # Gender risk (males slightly more likely to miss)
    if patient_data['gender'] == 1:  # Male
        risk_factors['gender_risk'] = 0.1
    
    # Indigenous status risk
    if patient_data['indigenous_status'] == 0:  # Aboriginal
        risk_factors['indigenous_risk'] = 0.2
    elif patient_data['indigenous_status'] == 1:  # Both
        risk_factors['indigenous_risk'] = 0.15
    
    # Marital status risk (single more likely to miss)
    if patient_data['marital_status'] == 2:  # Single
        risk_factors['marital_risk'] = 0.15
    
    # Language risk (non-English speakers more likely to miss)
    if patient_data['preferred_language'] != 0:  # Not English
        risk_factors['language_risk'] = 0.2
    
    # Interpreter required risk
    if patient_data['interpreter_required'] == 1:
        risk_factors['interpreter_risk'] = 0.25
    
    # Suburb risk (some suburbs have higher no-show rates)
    high_risk_suburbs = [2, 3, 6]  # Fremantle, Kardinya, North Lake
    if patient_data['suburb'] in high_risk_suburbs:
        risk_factors['suburb_risk'] = 0.1
    
    # Clinic risk (some clinics have higher no-show rates)
    high_risk_clinics = [2, 5, 6]  # ENT, Neurology, Oncology
    if patient_data['clinic'] in high_risk_clinics:
        risk_factors['clinic_risk'] = 0.1
    
    # Day of week risk (weekends and Mondays higher risk) - removed as not available in training data
    # if patient_data['day_of_week'] in [0, 5, 6]:  # Monday, Saturday, Sunday
    #     risk_factors['day_risk'] = 0.15
    
    # History risk based on previous appointments
    total_appointments = patient_data['appointments_attended'] + patient_data['appointments_missed'] + patient_data['appointments_rescheduled']
    if total_appointments > 0:
        missed_rate = patient_data['appointments_missed'] / total_appointments
        risk_factors['history_risk'] = min(missed_rate * 0.5, 0.3)
    
    # Last appointment DNS risk
    if patient_data['is_last_appt_dns'] == 1:
        risk_factors['history_risk'] += 0.2
    
    # Multiple appointments same day risk
    if patient_data['has_multiple_appts_same_day'] == 1:
        risk_factors['multiple_appts_risk'] = 0.15
    
    # Calculate total risk score (0-100)
    total_risk = sum(risk_factors.values()) * 100
    return min(total_risk, 100), risk_factors

# ==============================
# Model Management
# ==============================
def load_model():
    """Load the trained model"""
    try:
        return joblib.load("random_forest_model.pkl")
    except:
        return None

def retrain_model():
    """Retrain the model with current data"""
    try:
        df = load_data()
        if df.empty:
            return False, "No data available for retraining"
        
        # Prepare features (exclude target and date columns)
        feature_columns = [col for col in df.columns if col not in ['appointment_outcome', 'appointment_date', 'creation_date', 'appointment_time']]
        X = df[feature_columns].copy()
        
        # Encode categorical variables using the existing mappings
        for col in X.columns:
            if col in mappings:
                # Use the reverse mapping to convert string values to numeric
                X[col] = X[col].map(reverse_mappings[col])
        
        # Encode target variable
        outcome_mapping = {"Attended": 0, "DNS": 1, "Rescheduled": 2}
        y = df['appointment_outcome'].map(outcome_mapping)
        
        # Remove any rows with NaN values after encoding
        X = X.dropna()
        y = y.loc[X.index]
        
        if X.empty:
            return False, "No valid data after encoding"
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Train model
        model = RandomForestClassifier(n_estimators=100, random_state=42)
        model.fit(X_train, y_train)
        
        # Evaluate
        y_pred = model.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        
        # Save model
        joblib.dump(model, "random_forest_model.pkl")
        
        return True, f"Model retrained successfully. Accuracy: {accuracy:.3f}"
    except Exception as e:
        return False, f"Error retraining model: {str(e)}"

# ==============================
# Feature Mappings
# ==============================
mappings = {
    "appointment_outcome": {0: "Attended", 1: "DNS", 2: "Rescheduled"},
    "gender": {0: "Female", 1: "Male"},
    "indigenous_status": {0: "Aboriginal", 1: "Both", 2: "Neither", 3: "Torres Strait Islander"},
    "marital_status": {0: "Divorced", 1: "Married", 2: "Single", 3: "Widowed"},
    "country_of_birth": {0: "Australia", 1: "China", 2: "India", 3: "New Zealand", 4: "South Africa", 5: "UK", 6: "Vietnam"},
    "preferred_language": {0: "English", 1: "Hindu", 2: "Mandarin"},
    "interpreter_required": {0: "No", 1: "Yes"},
    "suburb": {0: "Bateman", 1: "Bull Creek", 2: "Fremantle", 3: "Kardinya", 4: "Leeming", 5: "Murdoch", 6: "North Lake", 7: "Palmyra", 8: "Willetton", 9: "Winthrop"},
    "clinic": {0: "Cardiology", 1: "Diabetes", 2: "ENT", 3: "Endocrinology", 4: "Gastroenterology", 5: "Neurology", 6: "Oncology", 7: "Ophthalmology", 8: "Orthopedics", 9: "Urology"},
    "day_of_week": {0: "Monday", 1: "Tuesday", 2: "Wednesday", 3: "Thursday", 4: "Friday", 5: "Saturday", 6: "Sunday"}
}

reverse_mappings = {col: {v: k for k, v in mapping.items()} for col, mapping in mappings.items()}

# ==============================
# Enhanced Calendar View
# ==============================
def _compute_dns_score_for_row(row: pd.Series) -> float:
    """Compute DNS risk score for a single appointment row using existing risk function."""
    try:
        patient_data = {
            'age': int(row['age']),
            'gender': reverse_mappings['gender'].get(row['gender'], 0),
            'indigenous_status': reverse_mappings['indigenous_status'].get(row['indigenous_status'], 2),
            'marital_status': reverse_mappings['marital_status'].get(row['marital_status'], 2),
            'preferred_language': reverse_mappings['preferred_language'].get(row['preferred_language'], 0),
            'interpreter_required': reverse_mappings['interpreter_required'].get(row['interpreter_required'], 0),
            'suburb': reverse_mappings['suburb'].get(row['suburb'], 0),
            'clinic': reverse_mappings['clinic'].get(row['clinic'], 0),
            'is_last_appt_dns': int(row.get('is_last_appt_dns', 0)),
            'has_multiple_appts_same_day': int(row.get('has_multiple_appts_same_day', 0)),
            'appointments_attended': int(row.get('appointments_attended', 0)),
            'appointments_missed': int(row.get('appointments_missed', 0)),
            'appointments_rescheduled': int(row.get('appointments_rescheduled', 0))
        }
        score, _ = calculate_dns_risk_score(patient_data)
        return float(score)
    except Exception:
        return 0.0

def _add_dns_scores(df_subset: pd.DataFrame) -> pd.DataFrame:
    """Return a copy of df_subset with a DNS_Risk_Score column computed per row."""
    if df_subset.empty:
        return df_subset.copy()
    result = df_subset.copy()
    result['DNS_Risk_Score'] = result.apply(_compute_dns_score_for_row, axis=1)
    return result

def create_monthly_calendar():
    """Create enhanced monthly calendar view with appointment counts and navigation"""
    st.subheader("📅 Interactive Monthly Calendar - Click on any date for details")
    
    # Load data first to get date range
    df = load_data()
    if df.empty:
        st.warning("No data available")
        return
    
    # Convert appointment dates and get date range
    df['appointment_date'] = pd.to_datetime(df['appointment_date'], format='%d/%m/%Y')
    min_date = df['appointment_date'].min()
    max_date = df['appointment_date'].max()
    
    # Navigation controls
    col1, col2, col3, col4 = st.columns([1, 1, 1, 2])
    
    with col1:
        if st.button("◀ Previous Month"):
            if 'selected_year' not in st.session_state:
                st.session_state.selected_year = datetime.now().year
            if 'selected_month' not in st.session_state:
                st.session_state.selected_month = datetime.now().month
            
            # Move to previous month
            if st.session_state.selected_month == 1:
                st.session_state.selected_month = 12
                st.session_state.selected_year -= 1
            else:
                st.session_state.selected_month -= 1
    
    with col2:
        if st.button("Next Month ▶"):
            if 'selected_year' not in st.session_state:
                st.session_state.selected_year = datetime.now().year
            if 'selected_month' not in st.session_state:
                st.session_state.selected_month = datetime.now().month
            
            # Move to next month
            if st.session_state.selected_month == 12:
                st.session_state.selected_month = 1
                st.session_state.selected_year += 1
            else:
                st.session_state.selected_month += 1
    
    with col3:
        if st.button("📅 Current Month"):
            st.session_state.selected_year = datetime.now().year
            st.session_state.selected_month = datetime.now().month
    
    with col4:
        st.write(f"**Data Range:** {min_date.strftime('%B %Y')} - {max_date.strftime('%B %Y')}")
    
    # Set default values if not in session state
    if 'selected_year' not in st.session_state:
        st.session_state.selected_year = datetime.now().year
    if 'selected_month' not in st.session_state:
        st.session_state.selected_month = datetime.now().month
    
    # Get selected month data
    year = st.session_state.selected_year
    month = st.session_state.selected_month
    first_day = datetime(year, month, 1)
    
    # Filter data for selected month
    month_data = df[df['appointment_date'].dt.strftime('%Y-%m') == f"{year}-{month:02d}"]
    
    if not month_data.empty:
        # Group by date and count appointments
        daily_counts = month_data.groupby(month_data['appointment_date'].dt.date).size().reset_index(name='count')
        daily_counts_dict = dict(zip(daily_counts['appointment_date'], daily_counts['count']))
        
        # Calculate statistics
        total_appointments = month_data.shape[0]
        attended_count = len(month_data[month_data['appointment_outcome'] == 'Attended'])
        dns_count = len(month_data[month_data['appointment_outcome'] == 'DNS'])
        rescheduled_count = len(month_data[month_data['appointment_outcome'] == 'Rescheduled'])
        
        # Display statistics
        st.write(f"### 📊 {first_day.strftime('%B %Y')} Statistics")
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Appointments", total_appointments)
        with col2:
            st.metric("Attended", attended_count, delta=f"{attended_count/total_appointments*100:.1f}%")
        with col3:
            st.metric("No-Show (DNS)", dns_count, delta=f"{dns_count/total_appointments*100:.1f}%")
        with col4:
            st.metric("Rescheduled", rescheduled_count, delta=f"{rescheduled_count/total_appointments*100:.1f}%")
        
        # Display calendar grid
        st.write(f"### 📅 {first_day.strftime('%B %Y')} Calendar - Click on any date for details")
        
        # Calendar header
        col1, col2, col3, col4, col5, col6, col7 = st.columns(7)
        days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        for i, day in enumerate(days):
            with [col1, col2, col3, col4, col5, col6, col7][i]:
                st.markdown(f"<div style='text-align: center; font-weight: bold; padding: 10px; background-color: #f0f2f6; border-radius: 5px;'>{day}</div>", unsafe_allow_html=True)
        
        # Calendar body
        current_date_obj = first_day
        week_count = 0
        
        while current_date_obj.month == month:
            # Start new week
            if current_date_obj.weekday() == 0 or week_count == 0:
                cols = st.columns(7)
                week_count += 1
            
            # Get day number and appointment count
            day_num = current_date_obj.day
            appointment_count = daily_counts_dict.get(current_date_obj.date(), 0)
            
            # Get appointment details for this day
            day_appointments = month_data[month_data['appointment_date'].dt.date == current_date_obj.date()]
            
            # Display day with appointment count
            day_col = cols[current_date_obj.weekday()]
            with day_col:
                if appointment_count > 0:
                    # Day with appointments - show different colors based on outcomes
                    is_future_day = current_date_obj.date() > datetime.now().date()
                    if is_future_day:
                        attended_today = 0
                        dns_today = 0
                        rescheduled_today = 0
                    else:
                        attended_today = len(day_appointments[day_appointments['appointment_outcome'] == 'Attended'])
                        dns_today = len(day_appointments[day_appointments['appointment_outcome'] == 'DNS'])
                        rescheduled_today = len(day_appointments[day_appointments['appointment_outcome'] == 'Rescheduled'])
                    
                    # Color coding based on DNS rate
                    # For future days use risk-based coloring instead of outcome-based rate
                    if is_future_day:
                        day_with_scores = _add_dns_scores(day_appointments)
                        high_risk_any = (day_with_scores['DNS_Risk_Score'] >= 80).any() if not day_with_scores.empty else False
                        med_risk_any = (day_with_scores['DNS_Risk_Score'] >= 40).any() if not day_with_scores.empty else False
                        if high_risk_any:
                            dns_rate = 0.31  # force red
                        elif med_risk_any:
                            dns_rate = 0.11  # force orange
                        else:
                            dns_rate = 0.0
                    else:
                        dns_rate = dns_today / appointment_count if appointment_count > 0 else 0
                    if dns_rate > 0.3:
                        border_color = "#ef4444"  # Red-500
                        bg_color = "rgba(239,68,68,0.18)"  # subtle red tint for dark bg
                        appt_color = "#ef4444"
                    elif dns_rate > 0.1:
                        border_color = "#f59e0b"  # Amber-500
                        bg_color = "rgba(245,158,11,0.15)"  # subtle amber tint
                        appt_color = "#f59e0b"
                    else:
                        border_color = "#22c55e"  # Green-500
                        bg_color = "rgba(34,197,94,0.15)"  # subtle green tint
                        appt_color = "#22c55e"

                    # If this is today's date, override with high-risk highlight if any patient DNS score ≥ 80
                    if current_date_obj.date() == datetime.now().date():
                        today_with_scores = _add_dns_scores(day_appointments)
                        if not today_with_scores.empty and (today_with_scores['DNS_Risk_Score'] >= 80).any():
                            border_color = "#ef4444"
                            bg_color = "rgba(239,68,68,0.18)"
                    
                    # Render colored box (HTML) and a small Details button for click
                    date_str = current_date_obj.strftime('%Y-%m-%d')
                    counts_line = "(Pending)" if is_future_day else f"✓{attended_today} ❌{dns_today} ↻{rescheduled_today}"
                    day_html = f"""
                    <div style='text-align: center; padding: 10px; margin: 2px; border: 2px solid {border_color}; 
                               background-color: {bg_color}; border-radius: 10px; min-height: 96px;'>
                        <div style='font-weight: 800; font-size: 18px; color: #e5e7eb;'>{day_num}</div>
                        <div style='font-size: 14px; color: {appt_color}; font-weight: 800;'>📅 {appointment_count}</div>
                        <div style='font-size: 11px; color: #cbd5e1;'>
                            {counts_line}
                        </div>
                    </div>
                    """
                    st.markdown(day_html, unsafe_allow_html=True)
                    if st.button("Details", key=f"date_{date_str}"):
                        st.session_state.selected_date = date_str
                        st.session_state.show_date_details = True
                        st.rerun()
                else:
                    # Empty day
                    st.button(f"{day_num}\n0", 
                            key=f"date_{current_date_obj.strftime('%Y-%m-%d')}", 
                            disabled=True,
                            use_container_width=True)
            
            current_date_obj += timedelta(days=1)
        
        # Legend
        st.write("### 📋 Legend")
        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown("🟢 **Low DNS Rate** (≤10%)")
        with col2:
            st.markdown("🟡 **Medium DNS Rate** (10-30%)")
        with col3:
            st.markdown("🔴 **High DNS Rate** (>30%)")
        
        # Show date details if a date was selected
        if st.session_state.get('show_date_details', False) and 'selected_date' in st.session_state:
            show_date_details(st.session_state['selected_date'], df)
        
        # Show today's patients with DNS scores and level coloring
        today = datetime.now().date()
        today_data = month_data[month_data['appointment_date'].dt.date == today]
        if not today_data.empty:
            st.write("---")
            st.write(f"### 🔎 Today's Patients DNS Scores ({today.strftime('%B %d, %Y')})")
            today_scored = _add_dns_scores(today_data)
            # Derive DNS level
            def _level(v: float) -> str:
                if v >= 80:
                    return 'High'
                if v >= 50:
                    return 'Moderate'
                return 'Low'
            today_scored['DNS_Level'] = today_scored['DNS_Risk_Score'].apply(_level)

            # Remove outcome column for today view and add DNS_Level
            display_cols = ['appointment_time', 'clinic', 'age', 'gender', 'suburb', 'DNS_Risk_Score', 'DNS_Level']
            available_cols = [c for c in display_cols if c in today_scored.columns]

            def _style_level_and_score(s):
                score = s.get('DNS_Risk_Score', 0)
                if score >= 80:
                    color = '#ffebee'; text = '#b71c1c'
                elif score >= 50:
                    color = '#fff8e1'; text = '#8d6e00'
                else:
                    color = '#e8f5e9'; text = '#1b5e20'
                styles = []
                for col in s.index:
                    if col in ('DNS_Risk_Score', 'DNS_Level'):
                        styles.append(f'background-color: {color}; color: {text}; font-weight: 600')
                    else:
                        styles.append('')
                return styles

            # Sort by appointment_time if available
            df_today_show = today_scored[available_cols].copy()
            if 'appointment_time' in df_today_show.columns:
                try:
                    df_today_show['_sort_time'] = pd.to_datetime(df_today_show['appointment_time'], format='%H:%M', errors='coerce')
                    df_today_show = df_today_show.sort_values('_sort_time').drop(columns=['_sort_time'])
                except Exception:
                    pass

            styled = df_today_show.style.apply(_style_level_and_score, axis=1).format({
                'DNS_Risk_Score': '{:.1f}'
            })
            st.dataframe(styled, use_container_width=True)
        
    else:
        st.info(f"No appointments found for {first_day.strftime('%B %Y')}")
        st.write("💡 **Tip:** Use the navigation buttons above to browse different months with appointment data.")

def show_date_details(selected_date, df):
    """Show detailed information for a selected date"""
    st.write("---")
    st.subheader(f"📅 Detailed View - {datetime.strptime(selected_date, '%Y-%m-%d').strftime('%B %d, %Y')}")
    
    # Convert selected date to match data format
    selected_date_obj = datetime.strptime(selected_date, '%Y-%m-%d').date()
    
    # Filter data for selected date
    date_data = df[df['appointment_date'].dt.date == selected_date_obj]
    
    if date_data.empty:
        st.info("No appointments found for this date.")
        return
    
    # Determine if selected date is in the future
    is_future_day = selected_date_obj > datetime.now().date()

    # Calculate statistics (for future, show pending and risk-based hints only)
    total_appointments = len(date_data)
    if is_future_day:
        attended_count = dns_count = rescheduled_count = 0
    else:
        attended_count = len(date_data[date_data['appointment_outcome'] == 'Attended'])
        dns_count = len(date_data[date_data['appointment_outcome'] == 'DNS'])
        rescheduled_count = len(date_data[date_data['appointment_outcome'] == 'Rescheduled'])
    
    # Calculate percentages
    attended_pct = (attended_count / total_appointments) * 100
    dns_pct = (dns_count / total_appointments) * 100
    rescheduled_pct = (rescheduled_count / total_appointments) * 100
    
    # Display key metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Appointments", total_appointments)
    with col2:
        st.metric("Attended", f"{attended_count} ({attended_pct:.1f}%)", 
                 delta=f"+{attended_pct:.1f}%" if attended_pct > 0 else None)
    with col3:
        st.metric("No-Show (DNS)", f"{dns_count} ({dns_pct:.1f}%)", 
                 delta=f"+{dns_pct:.1f}%" if dns_pct > 0 else None)
    with col4:
        st.metric("Rescheduled", f"{rescheduled_count} ({rescheduled_pct:.1f}%)", 
                 delta=f"+{rescheduled_pct:.1f}%" if rescheduled_pct > 0 else None)
    
    # Cumulative metrics up to selected date
    st.write("---")
    st.write("### 📈 Cumulative Until This Date")
    df_upto = df[df['appointment_date'].dt.date <= selected_date_obj]
    if not df_upto.empty:
        total_upto = len(df_upto)
        attended_upto = (df_upto['appointment_outcome'] == 'Attended').sum()
        dns_upto = (df_upto['appointment_outcome'] == 'DNS').sum()
        rescheduled_upto = (df_upto['appointment_outcome'] == 'Rescheduled').sum()
        att_pct_upto = attended_upto / total_upto * 100 if total_upto else 0
        dns_pct_upto = dns_upto / total_upto * 100 if total_upto else 0
        res_pct_upto = rescheduled_upto / total_upto * 100 if total_upto else 0

        c1, c2, c3, c4 = st.columns(4)
        with c1:
            st.metric("Total Appointments (to date)", total_upto)
        with c2:
            st.metric("Attended (to date)", f"{attended_upto} ({att_pct_upto:.1f}%)")
        with c3:
            st.metric("No-Show (DNS) (to date)", f"{dns_upto} ({dns_pct_upto:.1f}%)")
        with c4:
            st.metric("Rescheduled (to date)", f"{rescheduled_upto} ({res_pct_upto:.1f}%)")

    # Visual representation: DNS Levels chart (applies to past, today, and future)
    st.write("### 📊 DNS Risk Levels")
    with_scores = _add_dns_scores(date_data)
    if not with_scores.empty:
        def _level(v: float) -> str:
            if v >= 80:
                return 'High'
            if v >= 50:
                return 'Moderate'
            return 'Low'
        with_scores['DNS_Level'] = with_scores['DNS_Risk_Score'].apply(_level)

        level_counts = with_scores['DNS_Level'].value_counts().reindex(['High','Moderate','Low']).fillna(0).astype(int)
        level_df = pd.DataFrame({
            'Level': level_counts.index,
            'Count': level_counts.values
        })
        import plotly.express as px
        color_map = {'High': '#F44336', 'Moderate': '#FFC107', 'Low': '#4CAF50'}
        fig = px.pie(level_df, values='Count', names='Level', hole=0.45,
                     title=f"DNS Levels for {datetime.strptime(selected_date, '%Y-%m-%d').strftime('%B %d, %Y')}",
                     color='Level', color_discrete_map=color_map)
        st.plotly_chart(fig, use_container_width=True)
    
    # Clinic breakdown (only for past or today)
    if not is_future_day:
        st.write("### 🏥 Appointments by Clinic")
        # Simplify: show only Clinic and Total Appointments + bar chart
        clinic_counts = date_data.groupby('clinic').size().reset_index(name='Appointments')
        if not clinic_counts.empty:
            clinic_counts = clinic_counts.sort_values('Appointments', ascending=False)
            st.dataframe(clinic_counts, use_container_width=True)
            st.bar_chart(clinic_counts.set_index('clinic')['Appointments'])
    
    # Remove time analysis section
    
    # Detailed appointment list
    st.write("### 📋 Detailed Appointment List")
    
    # Add filters
    col1, col2 = st.columns(2)
    with col1:
        outcome_filter = st.selectbox("Filter by Outcome", ["All", "Attended", "DNS", "Rescheduled"])
    with col2:
        clinic_filter = st.selectbox("Filter by Clinic", ["All"] + list(date_data['clinic'].unique()))
    
    # Apply filters
    filtered_data = date_data.copy()
    if outcome_filter != "All" and not is_future_day:
        filtered_data = filtered_data[filtered_data['appointment_outcome'] == outcome_filter]
    if clinic_filter != "All":
        filtered_data = filtered_data[filtered_data['clinic'] == clinic_filter]
    
    # Display filtered data
    if not filtered_data.empty:
        # For future dates, compute DNS score and level and add styling; also hide outcome for today/future
        if is_future_day:
            filtered_scored = _add_dns_scores(filtered_data)
            def _level(v: float) -> str:
                if v >= 80:
                    return 'High'
                if v >= 50:
                    return 'Moderate'
                return 'Low'
            filtered_scored['DNS_Level'] = filtered_scored['DNS_Risk_Score'].apply(_level)
        else:
            filtered_scored = filtered_data.copy()

        display_columns = ['appointment_time', 'clinic', 'appointment_outcome', 'age', 'gender', 'suburb']
        if is_future_day:
            display_columns += ['DNS_Risk_Score', 'DNS_Level']
        available_columns = [col for col in display_columns if col in filtered_scored.columns]
        if (is_future_day or selected_date_obj == datetime.now().date()) and 'appointment_outcome' in available_columns:
            available_columns.remove('appointment_outcome')

        # Sort by appointment_time if available
        df_to_show = filtered_scored[available_columns].copy()
        if 'appointment_time' in df_to_show.columns:
            try:
                df_to_show['_sort_time'] = pd.to_datetime(df_to_show['appointment_time'], format='%H:%M', errors='coerce')
                df_to_show = df_to_show.sort_values('_sort_time').drop(columns=['_sort_time'])
            except Exception:
                pass

        if is_future_day and 'DNS_Risk_Score' in df_to_show.columns:
            def _style_level_and_score(s):
                score = s.get('DNS_Risk_Score', 0)
                if score >= 80:
                    color = '#ffebee'; text = '#b71c1c'
                elif score >= 50:
                    color = '#fff8e1'; text = '#8d6e00'
                else:
                    color = '#e8f5e9'; text = '#1b5e20'
                styles = []
                for col in s.index:
                    if col in ('DNS_Risk_Score', 'DNS_Level'):
                        styles.append(f'background-color: {color}; color: {text}; font-weight: 600')
                    else:
                        styles.append('')
                return styles
            styled = df_to_show.style.apply(_style_level_and_score, axis=1).format({'DNS_Risk_Score': '{:.1f}'})
            st.dataframe(styled, use_container_width=True)
        else:
            st.dataframe(df_to_show, use_container_width=True)
        
        # Download button for detailed data
        csv_data = filtered_data.to_csv(index=False)
        st.download_button("⬇ Download Detailed Data for This Date", 
                         csv_data, 
                         file_name=f"appointments_{selected_date}.csv", 
                         mime="text/csv")
    else:
        st.info("No appointments match the selected filters.")
    
    # Close button
    if st.button("❌ Close Date Details"):
        st.session_state.show_date_details = False
        st.rerun()

# ==============================
# Admin Functions
# ==============================
def admin_dashboard():
    """Admin dashboard with all advanced features"""
    st.title("🏥 Admin Dashboard - Outpatient Appointment Prediction")
    
    # Sidebar navigation buttons
    st.sidebar.title("Admin Panel")
    st.sidebar.markdown("---")
    
    # Navigation buttons
    if st.sidebar.button("🎯 Prediction & DNS Score", use_container_width=True):
        st.session_state.admin_page = "prediction"
    if st.sidebar.button("📅 Calendar View", use_container_width=True):
        st.session_state.admin_page = "calendar"
    if st.sidebar.button("📂 Bulk Prediction", use_container_width=True):
        st.session_state.admin_page = "bulk"
    if st.sidebar.button("🔄 Model Retraining", use_container_width=True):
        st.session_state.admin_page = "retrain"
    if st.sidebar.button("📊 DNS History", use_container_width=True):
        st.session_state.admin_page = "history"
    
    # Initialize default page if not set
    if 'admin_page' not in st.session_state:
        st.session_state.admin_page = "prediction"
    
    # Display content based on selected page
    if st.session_state.admin_page == "prediction":
        prediction_and_dns_score()
    elif st.session_state.admin_page == "calendar":
        create_monthly_calendar()
    elif st.session_state.admin_page == "bulk":
        bulk_prediction_with_dns()
    elif st.session_state.admin_page == "retrain":
        model_retraining_interface()
    elif st.session_state.admin_page == "history":
        dns_score_history()

def prediction_and_dns_score():
    """Enhanced prediction with DNS risk score"""
    st.subheader("🎯 Prediction & DNS Risk Score")
    
    model = load_model()
    if model is None:
        st.error("Model not found. Please retrain the model first.")
        return
    
    # Input form
    with st.form("prediction_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            age = st.slider("Age", min_value=0, max_value=100, value=40)
            gender = st.selectbox("Gender", list(reverse_mappings["gender"].keys()))
            indigenous_status = st.selectbox("Indigenous Status", list(reverse_mappings["indigenous_status"].keys()))
            marital_status = st.selectbox("Marital Status", list(reverse_mappings["marital_status"].keys()))
            country_of_birth = st.selectbox("Country of Birth", list(reverse_mappings["country_of_birth"].keys()))
            preferred_language = st.selectbox("Preferred Language", list(reverse_mappings["preferred_language"].keys()))
        
        with col2:
            interpreter_required = st.selectbox("Interpreter Required", list(reverse_mappings["interpreter_required"].keys()))
            suburb = st.selectbox("Suburb", list(reverse_mappings["suburb"].keys()))
            clinic = st.selectbox("Clinic", list(reverse_mappings["clinic"].keys()))
            is_last_appt_dns = st.selectbox("Last Appointment DNA?", [0, 1])
            has_multiple_appts_same_day = st.selectbox("Multiple Appointments Same Day?", [0, 1])
        
        appointments_attended = st.number_input("Appointments Attended", 0, 100, 5)
        appointments_missed = st.number_input("Appointments Missed", 0, 50, 1)
        appointments_rescheduled = st.number_input("Appointments Rescheduled", 0, 50, 0)
        
        submit_button = st.form_submit_button("Predict & Calculate DNS Score")
        
        if submit_button:
            # Prepare input data
            input_data = pd.DataFrame([[
                age, reverse_mappings["gender"][gender], reverse_mappings["indigenous_status"][indigenous_status],
                reverse_mappings["marital_status"][marital_status], reverse_mappings["country_of_birth"][country_of_birth],
                reverse_mappings["preferred_language"][preferred_language], reverse_mappings["interpreter_required"][interpreter_required],
                reverse_mappings["suburb"][suburb], reverse_mappings["clinic"][clinic], is_last_appt_dns,
                has_multiple_appts_same_day, appointments_attended, appointments_missed, appointments_rescheduled
            ]], columns=[
                "age", "gender", "indigenous_status", "marital_status", "country_of_birth",
                "preferred_language", "interpreter_required", "suburb", "clinic",
                "is_last_appt_dns", "has_multiple_appts_same_day", "appointments_attended",
                "appointments_missed", "appointments_rescheduled"
            ])

            # Make prediction
            prediction = model.predict(input_data)[0]
            proba = model.predict_proba(input_data)[0]
            outcome = mappings["appointment_outcome"][prediction]
            
            # Calculate DNS risk score
            patient_data = {
                'age': age, 'gender': reverse_mappings["gender"][gender],
                'indigenous_status': reverse_mappings["indigenous_status"][indigenous_status],
                'marital_status': reverse_mappings["marital_status"][marital_status],
                'preferred_language': reverse_mappings["preferred_language"][preferred_language],
                'interpreter_required': reverse_mappings["interpreter_required"][interpreter_required],
                'suburb': reverse_mappings["suburb"][suburb], 'clinic': reverse_mappings["clinic"][clinic],
                'is_last_appt_dns': is_last_appt_dns, 'has_multiple_appts_same_day': has_multiple_appts_same_day,
                'appointments_attended': appointments_attended, 'appointments_missed': appointments_missed,
                'appointments_rescheduled': appointments_rescheduled
            }
            
            dns_score, risk_factors = calculate_dns_risk_score(patient_data)
            
            # Display results
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("🎯 Prediction Result")
                st.write(f"**Predicted Outcome:** {outcome}")
                
                # Probability chart
                prob_df = pd.DataFrame({
                    "Outcome": [mappings["appointment_outcome"][i] for i in range(len(proba))],
                    "Probability": proba
                })
                st.bar_chart(prob_df.set_index("Outcome"))
            
            with col2:
                st.subheader("⚠️ DNS Risk Score")
                st.metric("DNS Risk Score", f"{dns_score:.1f}/100")
                
                # Risk level indicator
                if dns_score < 30:
                    st.success("🟢 Low Risk")
                elif dns_score < 60:
                    st.warning("🟡 Medium Risk")
                else:
                    st.error("🔴 High Risk")
                
                # Risk factors breakdown
                st.write("**Risk Factors:**")
                for factor, value in risk_factors.items():
                    if value > 0:
                        st.write(f"- {factor.replace('_', ' ').title()}: {value*100:.1f}%")
            
            # Store data in session state for saving outside form
            st.session_state.prediction_data = {
                'patient_data': patient_data,
                'dns_score': dns_score,
                'risk_factors': risk_factors,
                'prediction': outcome
            }
    
    # Save DNS score button (outside form)
    if 'prediction_data' in st.session_state:
        if st.button("Save DNS Score"):
            score_data = {
                'timestamp': datetime.now().isoformat(),
                'patient_data': st.session_state.prediction_data['patient_data'],
                'dns_score': st.session_state.prediction_data['dns_score'],
                'risk_factors': st.session_state.prediction_data['risk_factors'],
                'prediction': st.session_state.prediction_data['prediction']
            }
            save_dns_scores([score_data])
            st.success("DNS score saved successfully!")
            # Clear the session state
            del st.session_state.prediction_data

def bulk_prediction_with_dns():
    """Bulk prediction with DNS scores"""
    st.subheader("📂 Bulk Prediction with DNS Scores")
    
    model = load_model()
    if model is None:
        st.error("Model not found. Please retrain the model first.")
        return
    
    file_upload = st.file_uploader("Upload CSV file for bulk prediction", type=["csv"])
    
    if file_upload:
        try:
            df_upload = pd.read_csv(file_upload)
            st.write("### Uploaded Data Preview")
            st.dataframe(df_upload.head())
            
            if st.button("Run Bulk Prediction"):
                # Prepare features exactly like training: drop date/target columns and encode categoricals
                feature_columns = [
                    col for col in df_upload.columns 
                    if col not in ['appointment_outcome', 'appointment_date', 'creation_date', 'appointment_time']
                ]
                X = df_upload[feature_columns].copy()

                # Encode categorical variables using reverse_mappings
                for col in X.columns:
                    if col in reverse_mappings:
                        X[col] = X[col].map(reverse_mappings[col])

                # Handle any unmapped values by filling with 0 (or reasonable default)
                X = X.fillna(0)

                # Make predictions on encoded features
                predictions = model.predict(X)
                probabilities = model.predict_proba(X)
                
                # Calculate DNS scores for each row
                dns_scores = df_upload.apply(_compute_dns_score_for_row, axis=1).tolist()
                risk_factors_list = []
                for idx, row in df_upload.iterrows():
                    # For transparency provide contributing factors as well
                    score, factors = calculate_dns_risk_score({
                        'age': int(row.get('age', 0)),
                        'gender': reverse_mappings['gender'].get(row.get('gender'), 0),
                        'indigenous_status': reverse_mappings['indigenous_status'].get(row.get('indigenous_status'), 2),
                        'marital_status': reverse_mappings['marital_status'].get(row.get('marital_status'), 2),
                        'preferred_language': reverse_mappings['preferred_language'].get(row.get('preferred_language'), 0),
                        'interpreter_required': reverse_mappings['interpreter_required'].get(row.get('interpreter_required'), 0),
                        'suburb': reverse_mappings['suburb'].get(row.get('suburb'), 0),
                        'clinic': reverse_mappings['clinic'].get(row.get('clinic'), 0),
                        'is_last_appt_dns': int(row.get('is_last_appt_dns', 0)),
                        'has_multiple_appts_same_day': int(row.get('has_multiple_appts_same_day', 0)),
                        'appointments_attended': int(row.get('appointments_attended', 0)),
                        'appointments_missed': int(row.get('appointments_missed', 0)),
                        'appointments_rescheduled': int(row.get('appointments_rescheduled', 0))
                    })
                    risk_factors_list.append(factors)
                
                # Add results to dataframe
                df_upload["Predicted_Outcome"] = [mappings["appointment_outcome"][p] for p in predictions]
                df_upload["DNS_Risk_Score"] = dns_scores
                df_upload["Attended_Probability"] = probabilities[:, 0]
                df_upload["DNS_Probability"] = probabilities[:, 1]
                df_upload["Rescheduled_Probability"] = probabilities[:, 2]
                
                st.write("### Prediction Results")
                st.dataframe(df_upload)
                
                # Download results
                csv_data = df_upload.to_csv(index=False)
                st.download_button("⬇ Download Results with DNS Scores", 
                                 csv_data, 
                                 file_name="bulk_predictions_with_dns.csv", 
                                 mime="text/csv")
                
                # Save DNS scores
                if st.button("Save All DNS Scores"):
                    score_data_list = []
                    for idx, row in df_upload.iterrows():
                        score_data = {
                            'timestamp': datetime.now().isoformat(),
                            'patient_data': row.to_dict(),
                            'dns_score': float(dns_scores[idx]),
                            'risk_factors': risk_factors_list[idx],
                            'prediction': df_upload.loc[idx, "Predicted_Outcome"]
                        }
                        score_data_list.append(score_data)
                    
                    save_dns_scores(score_data_list)
                    st.success(f"Saved {len(score_data_list)} DNS scores successfully!")
        
        except Exception as e:
            st.error(f"Error processing file: {str(e)}")

def model_retraining_interface():
    """Model retraining interface for admin"""
    st.subheader("🔄 Model Retraining")
    
    st.write("Retrain the machine learning model with the latest data.")
    
    if st.button("Retrain Model"):
        with st.spinner("Retraining model..."):
            success, message = retrain_model()
            
            if success:
                st.success(message)
            else:
                st.error(message)


def dns_score_history():
    """Display DNS score history"""
    st.subheader("📊 DNS Score History")
    
    scores = load_dns_scores()
    
    if not scores:
        st.info("No DNS scores saved yet.")
        return
    
    # Convert to DataFrame for display
    df_scores = pd.DataFrame(scores)
    df_scores['timestamp'] = pd.to_datetime(df_scores['timestamp'])
    
    # Display recent scores
    st.write("### Recent DNS Scores")
    recent_scores = df_scores.tail(20)
    
    for idx, row in recent_scores.iterrows():
        with st.expander(f"Score: {row['dns_score']:.1f} - {row['timestamp'].strftime('%Y-%m-%d %H:%M')}"):
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Patient Data:**")
                for key, value in row['patient_data'].items():
                    st.write(f"- {key}: {value}")
            
            with col2:
                st.write("**Risk Factors:**")
                for factor, value in row['risk_factors'].items():
                    if value > 0:
                        st.write(f"- {factor.replace('_', ' ').title()}: {value*100:.1f}%")
    
    # Statistics
    st.write("### DNS Score Statistics")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Average DNS Score", f"{df_scores['dns_score'].mean():.1f}")
    
    with col2:
        st.metric("Highest DNS Score", f"{df_scores['dns_score'].max():.1f}")
    
    with col3:
        st.metric("Total Records", len(df_scores))

# ==============================
# User Functions
# ==============================
def user_dashboard():
    """Simple user dashboard with basic form completion"""
    st.title("🏥 Patient Appointment Form")
    st.write("Please fill out the form below to complete your appointment details.")
    
    with st.form("user_form"):
        st.subheader("Personal Information")
        
        col1, col2 = st.columns(2)
        
        with col1:
            name = st.text_input("Full Name*")
            age = st.number_input("Age*", min_value=0, max_value=120, value=25)
            gender = st.selectbox("Gender*", ["Male", "Female", "Other"])
            phone = st.text_input("Phone Number*")
        
        with col2:
            email = st.text_input("Email Address*")
            address = st.text_area("Address*")
            emergency_contact = st.text_input("Emergency Contact")
            emergency_phone = st.text_input("Emergency Contact Phone")
        
        st.subheader("Appointment Details")
        
        col3, col4 = st.columns(2)
        
        with col3:
            preferred_date = st.date_input("Preferred Date*", value=datetime.now().date() + timedelta(days=7))
            preferred_time = st.time_input("Preferred Time*", value=datetime.now().time())
            clinic_preference = st.selectbox("Clinic Preference*", [
                "Cardiology", "Diabetes", "ENT", "Endocrinology", "Gastroenterology",
                "Neurology", "Oncology", "Ophthalmology", "Orthopedics", "Urology"
            ])
        
        with col4:
            reason_for_visit = st.text_area("Reason for Visit*")
            symptoms = st.text_area("Current Symptoms")
            medications = st.text_area("Current Medications")
            allergies = st.text_area("Known Allergies")
        
        st.subheader("Additional Information")
        
        interpreter_needed = st.selectbox("Do you need an interpreter?", ["No", "Yes"])
        special_requirements = st.text_area("Special Requirements or Accessibility Needs")
        insurance_info = st.text_input("Insurance Information")
        
        # Form validation
        required_fields = [name, age, phone, email, address, reason_for_visit]
        
        submit_button = st.form_submit_button("Submit Appointment Request")
        
        if submit_button:
            if all(required_fields):
                st.success("✅ Appointment request submitted successfully!")
                st.write("**Submitted Information:**")
                
                submitted_data = {
                    "Name": name,
                    "Age": age,
                    "Gender": gender,
                    "Phone": phone,
                    "Email": email,
                    "Address": address,
                    "Preferred Date": preferred_date,
                    "Preferred Time": preferred_time,
                    "Clinic": clinic_preference,
                    "Reason": reason_for_visit
                }
                
                for key, value in submitted_data.items():
                    st.write(f"**{key}:** {value}")
                
                st.info("📞 You will receive a confirmation call within 24 hours to schedule your appointment.")
                
            else:
                st.error("❌ Please fill in all required fields (marked with *)")

# ==============================
# Main Application
# ==============================
def main():
    # Apply background to the entire application
    _apply_background(_load_default_bg_bytes())
    
    # Check if user is logged in
    if "logged_in" not in st.session_state:
        login_page()
        return
    
    # Logout button
    if st.sidebar.button("Logout"):
        logout()
        return
    
    # Display user info
    st.sidebar.write(f"Logged in as: **{st.session_state.username}**")
    
    # Route to appropriate dashboard
    if st.session_state.is_admin:
        admin_dashboard()
    else:
        user_dashboard()

if __name__ == "__main__":
    main()